/**
 * Scrolls to an in-page section by id, even if that section is a lazily-mounted
 * home-page block that has not been rendered yet.
 *
 * 1. If the element already exists -> scroll immediately.
 * 2. Otherwise ask every <LazySection> to mount, then poll (max ~4s) until the
 *    target exists and scroll to it.
 */
export const MOUNT_ALL_SECTIONS_EVENT = 'raba:mount-all-sections';

export function scrollToSectionId(id: string, behavior: ScrollBehavior = 'smooth'): void {
  if (typeof document === 'undefined' || !id) return;

  const go = (el: HTMLElement) => el.scrollIntoView({ behavior, block: 'start' });

  const existing = document.getElementById(id);
  if (existing) {
    go(existing);
    return;
  }

  window.dispatchEvent(new Event(MOUNT_ALL_SECTIONS_EVENT));

  let tries = 0;
  const poll = () => {
    const el = document.getElementById(id);
    if (el) {
      requestAnimationFrame(() => go(el));
      return;
    }
    if (++tries < 40) window.setTimeout(poll, 100);
  };
  window.setTimeout(poll, 60);
}
