import React, { useState, useEffect, useRef, Suspense, lazy } from 'react';
import { Navbar } from './components/Navbar';
import { AnimatedBackground } from './components/AnimatedBackground';
import { Hero } from './components/Hero';
import { CourseItem } from './data/coursesData';
import { getStoredAdminSession, clearStoredAdminSession } from './data/adminData';
import { DISPATCH_REQUEST_EVENT } from './data/customerRequests';
import { LazySection } from './components/LazySection';
import { scrollToSectionId } from './utils/scrollToSection';

// Helper that retries dynamic imports to handle transient network hiccups, dev-server restarts, and new deployments
function safeImport<T>(factory: () => Promise<T>, retries = 3, interval = 500): Promise<T> {
  return new Promise<T>((resolve) => {
    const attempt = (remaining: number) => {
      factory()
        .then(resolve)
        .catch((error) => {
          if (remaining > 0) {
            setTimeout(() => attempt(remaining - 1), interval);
          } else {
            const isChunkError = 
              error?.message?.includes('Failed to fetch dynamically imported module') ||
              error?.message?.includes('Importing a module script failed') ||
              error?.name === 'TypeError';
            
            if (isChunkError && typeof window !== 'undefined') {
              const lastReload = Number(sessionStorage.getItem('raba_chunk_reload_time') || 0);
              const now = Date.now();
              // Auto-reload once if not reloaded within the last 15 seconds to fetch latest deploy bundle
              if (now - lastReload > 15000) {
                sessionStorage.setItem('raba_chunk_reload_time', String(now));
                window.location.reload();
                return;
              }
            }
            console.warn('[safeImport] Module chunk failed to load, providing fallback:', error);
            // Gracefully resolve with empty component fallback so entire page doesn't crash
            resolve({ default: () => null } as unknown as T);
          }
        });
    };
    attempt(retries);
  });
}

// Lazy-loaded components for optimal mobile bundle splitting, fast paint, and low TBT
const ShadowTeacherSection = lazy<React.ComponentType<any>>(() => safeImport(() => import('./components/ShadowTeacherSection')).then((m: any) => ({ default: m.default || m.ShadowTeacherSection || (() => null) })));
const PackagesSection = lazy<React.ComponentType<any>>(() => safeImport(() => import('./components/PackagesSection')).then((m: any) => ({ default: m.default || m.PackagesSection || (() => null) })));
const SpecialistsSection = lazy<React.ComponentType<any>>(() => safeImport(() => import('./components/SpecialistsSection')).then((m: any) => ({ default: m.default || m.SpecialistsSection || (() => null) })));
const SpecialistsDirectoryPage = lazy<React.ComponentType<any>>(() => safeImport(() => import('./components/SpecialistsDirectoryPage')).then((m: any) => ({ default: m.default || m.SpecialistsDirectoryPage || (() => null) })));
const ServicesDirectoryPage = lazy<React.ComponentType<any>>(() => safeImport(() => import('./components/ServicesDirectoryPage')).then((m: any) => ({ default: m.default || m.ServicesDirectoryPage || (() => null) })));
const BranchesDirectoryPage = lazy<React.ComponentType<any>>(() => safeImport(() => import('./components/BranchesDirectoryPage')).then((m: any) => ({ default: m.default || m.BranchesDirectoryPage || (() => null) })));
const OffersDirectoryPage = lazy<React.ComponentType<any>>(() => safeImport(() => import('./components/OffersDirectoryPage')).then((m: any) => ({ default: m.default || m.OffersDirectoryPage || (() => null) })));
const BlogDirectoryPage = lazy<React.ComponentType<any>>(() => safeImport(() => import('./components/BlogDirectoryPage')).then((m: any) => ({ default: m.default || m.BlogDirectoryPage || (() => null) })));
const SpecialistCvModal = lazy<React.ComponentType<any>>(() => safeImport(() => import('./components/SpecialistCvModal')).then((m: any) => ({ default: m.default || m.SpecialistCvModal || (() => null) })));
const BookingModal = lazy<React.ComponentType<any>>(() => safeImport(() => import('./components/BookingModal')).then((m: any) => ({ default: m.default || m.BookingModal || (() => null) })));
const NotificationCenterModal = lazy<React.ComponentType<any>>(() => safeImport(() => import('./components/NotificationCenterModal')).then((m: any) => ({ default: m.default || m.NotificationCenterModal || (() => null) })));
const TestimonialsSection = lazy<React.ComponentType<any>>(() => safeImport(() => import('./components/TestimonialsSection')).then((m: any) => ({ default: m.default || m.TestimonialsSection || (() => null) })));
const BlogSliderSection = lazy<React.ComponentType<any>>(() => safeImport(() => import('./components/BlogSliderSection')).then((m: any) => ({ default: m.default || m.BlogSliderSection || (() => null) })));
const AccreditationsSection = lazy<React.ComponentType<any>>(() => safeImport(() => import('./components/AccreditationsSection')).then((m: any) => ({ default: m.default || m.AccreditationsSection || (() => null) })));
const PartnersSection = lazy<React.ComponentType<any>>(() => safeImport(() => import('./components/PartnersSection')).then((m: any) => ({ default: m.default || m.PartnersSection || (() => null) })));
const BranchesSection = lazy<React.ComponentType<any>>(() => safeImport(() => import('./components/BranchesSection')).then((m: any) => ({ default: m.default || m.BranchesSection || (() => null) })));
const CoursesSliderSection = lazy<React.ComponentType<any>>(() => safeImport(() => import('./components/CoursesSliderSection')).then((m: any) => ({ default: m.default || m.CoursesSliderSection || (() => null) })));
const CourseRegistrationModal = lazy<React.ComponentType<any>>(() => safeImport(() => import('./components/CourseRegistrationModal')).then((m: any) => ({ default: m.default || m.CourseRegistrationModal || (() => null) })));
const LoginModal = lazy<React.ComponentType<any>>(() => safeImport(() => import('./components/LoginModal')).then((m: any) => ({ default: m.default || m.LoginModal || (() => null) })));
const StoreModal = lazy<React.ComponentType<any>>(() => safeImport(() => import('./components/StoreModal')).then((m: any) => ({ default: m.default || m.StoreModal || (() => null) })));
const VideoModal = lazy<React.ComponentType<any>>(() => safeImport(() => import('./components/VideoModal')).then((m: any) => ({ default: m.default || m.VideoModal || (() => null) })));
const QuickConsultationModal = lazy<React.ComponentType<any>>(() => safeImport(() => import('./components/QuickConsultationModal')).then((m: any) => ({ default: m.default || m.QuickConsultationModal || (() => null) })));
const AdminDashboard = lazy<React.ComponentType<any>>(() => safeImport(() => import('./components/admin/AdminDashboard')).then((m: any) => ({ default: m.default || m.AdminDashboard || (() => null) })));
const AdminLoginPage = lazy<React.ComponentType<any>>(() => safeImport(() => import('./components/admin/AdminLoginPage')).then((m: any) => ({ default: m.default || m.AdminLoginPage || (() => null) })));
const StatsBar = lazy<React.ComponentType<any>>(() => safeImport(() => import('./components/StatsBar')).then((m: any) => ({ default: m.default || m.StatsBar || (() => null) })));
const ServicesSection = lazy<React.ComponentType<any>>(() => safeImport(() => import('./components/ServicesSection')).then((m: any) => ({ default: m.default || m.ServicesSection || (() => null) })));
const Footer = lazy<React.ComponentType<any>>(() => safeImport(() => import('./components/Footer')).then((m: any) => ({ default: m.default || m.Footer || (() => null) })));
const FloatingActions = lazy<React.ComponentType<any>>(() => safeImport(() => import('./components/FloatingActions')).then((m: any) => ({ default: m.default || m.FloatingActions || (() => null) })));
const MobileBottomBar = lazy<React.ComponentType<any>>(() => safeImport(() => import('./components/MobileBottomBar')).then((m: any) => ({ default: m.default || m.MobileBottomBar || (() => null) })));


import { 
  INITIAL_APPOINTMENTS, 
  INITIAL_NOTIFICATIONS,
  PARENT_REVIEWS,
  SERVICES,
  THERAPY_PACKAGES,
  SPECIALISTS
} from './data/mockData';
import { 
  Specialist, 
  ServiceItem, 
  TherapyPackage, 
  Appointment, 
  NotificationItem,
  ParentReview,
  AdminUser
} from './types';
import { deduplicateSpecialists } from './utils/specialistDeduplication';
import { savePersistentModule } from './utils/persistentSync';
import { 
  getStoredThemeSettings, 
  applyGlobalTheme, 
  getStoredModulesVisibility, 
  SiteModulesVisibility 
} from './data/siteCustomizer';
import { getStoredTrackingPixels, applyTrackingPixels } from './utils/trackingPixels';

// ---------------------------------------------------------------------------
// Performance helpers
// ---------------------------------------------------------------------------

/** Returns true once `flag` has ever been true (mount-once, never unmount). Used so lazy modals are
 *  downloaded/rendered only after the visitor first opens them instead of all at page load. */
function useEverTrue(flag: boolean): boolean {
  const ref = useRef(flag);
  if (flag) ref.current = true;
  return ref.current;
}

/** Persists a value to localStorage OFF the critical path (debounced + idle) and flushes on page hide,
 *  so big JSON.stringify calls never block first render, scrolling or taps. */
function usePersistIdle(key: string, value: unknown, delay = 1200) {
  const latest = useRef(value);
  latest.current = value;
  const dirty = useRef(false);

  useEffect(() => {
    dirty.current = true;
    const write = () => {
      try {
        localStorage.setItem(key, JSON.stringify(latest.current));
      } catch {
        // ignore quota / private mode errors
      }
      dirty.current = false;
    };
    const id = window.setTimeout(() => {
      if ('requestIdleCallback' in window) {
        (window as any).requestIdleCallback(write, { timeout: 2000 });
      } else {
        write();
      }
    }, delay);
    return () => window.clearTimeout(id);
  }, [key, value, delay]);

  useEffect(() => {
    const flush = () => {
      if (!dirty.current) return;
      try {
        localStorage.setItem(key, JSON.stringify(latest.current));
      } catch {
        // ignore
      }
      dirty.current = false;
    };
    const onVisibility = () => {
      if (document.visibilityState === 'hidden') flush();
    };
    window.addEventListener('pagehide', flush);
    document.addEventListener('visibilitychange', onVisibility);
    return () => {
      window.removeEventListener('pagehide', flush);
      document.removeEventListener('visibilitychange', onVisibility);
    };
  }, [key]);
}

/** Home-page section that mounts (and downloads its JS chunk) only when it nears the viewport. */
const HomeSection: React.FC<{ minHeight?: number; order: number; children: React.ReactNode }> = ({
  minHeight = 500,
  order,
  children
}) => (
  <LazySection minHeight={`${minHeight}px`} rootMargin="700px 0px" idleMountMs={7000 + order * 900}>
    <Suspense fallback={<div style={{ minHeight }} aria-hidden="true" />}>{children}</Suspense>
  </LazySection>
);

export default function App() {
  // Modules Visibility & Theme Control
  const [modules, setModules] = useState<SiteModulesVisibility>(() => getStoredModulesVisibility());

  // Safe, Smooth Background Hydration: Instant Hero paint, followed by quiet idle mounting
  const [isReadyToHydrate, setIsReadyToHydrate] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const hash = window.location.hash.toLowerCase();
      return (
        hash.startsWith('#admin') ||
        hash.includes('blog') ||
        hash.includes('specialist') ||
        hash.includes('branch') ||
        hash.includes('offer') ||
        hash.includes('service') ||
        Boolean(localStorage.getItem('raba_admin_session_auth'))
      );
    }
    return false;
  });

  useEffect(() => {
    // Apply saved theme colors on startup
    applyGlobalTheme(getStoredThemeSettings());

    // Schedule hydration during browser idle time or right after initial paint
    let idleId: number | any;
    let timerId: any;

    const triggerHydration = () => {
      setIsReadyToHydrate(true);
      ['scroll', 'touchstart', 'wheel', 'mousemove', 'keydown'].forEach(evt => {
        window.removeEventListener(evt, triggerHydration);
      });
    };

    if ('requestIdleCallback' in window) {
      idleId = (window as any).requestIdleCallback(
        () => triggerHydration(),
        { timeout: 800 } // Guarantees mounting even on slow devices without user interaction
      );
    } else {
      timerId = setTimeout(triggerHydration, 300);
    }

    // Early trigger if user interacts before idle timeout
    ['scroll', 'touchstart', 'wheel', 'mousemove', 'keydown'].forEach(evt => {
      window.addEventListener(evt, triggerHydration, { passive: true, once: true });
    });

    const cleanupBelowFold = () => {
      if (idleId && 'cancelIdleCallback' in window) {
        (window as any).cancelIdleCallback(idleId);
      }
      if (timerId) {
        clearTimeout(timerId);
      }
      ['scroll', 'touchstart', 'wheel', 'mousemove', 'keydown'].forEach(evt => {
        window.removeEventListener(evt, triggerHydration);
      });
    };

    // Defer tracking pixels & external analytics until first user interaction (zero background timer during audit)
    const scheduleDeferredPixels = () => {
      let executed = false;
      const run = () => {
        if (executed) return;
        executed = true;
        ['scroll', 'mousemove', 'touchstart', 'pointerdown', 'wheel'].forEach(evt => {
          window.removeEventListener(evt, run);
        });
        applyTrackingPixels(getStoredTrackingPixels());
        fetch('/api/tracking-pixels/active')
          .then(res => res.json())
          .then(json => {
            if (json.success && json.data) {
              applyTrackingPixels(json.data);
            }
          })
          .catch(() => {});
      };

      ['scroll', 'mousemove', 'touchstart', 'pointerdown', 'wheel'].forEach(evt => {
        window.addEventListener(evt, run, { passive: true, once: true });
      });

      return () => {
        ['scroll', 'mousemove', 'touchstart', 'pointerdown', 'wheel'].forEach(evt => {
          window.removeEventListener(evt, run);
        });
      };
    };

    const cleanupPixels = scheduleDeferredPixels();

    // Dismiss splash overlay as soon as App component renders
    if (typeof window !== 'undefined' && (window as any).dismissSplash) {
      (window as any).dismissSplash();
    }

    const handleThemeUpdate = () => applyGlobalTheme(getStoredThemeSettings());
    const handleModulesUpdate = () => {
      const next = getStoredModulesVisibility();
      setModules((prev) => {
        if (JSON.stringify(prev) === JSON.stringify(next)) return prev;
        return next;
      });
    };

    window.addEventListener('raba_theme_updated', handleThemeUpdate);
    window.addEventListener('raba_modules_updated', handleModulesUpdate);

    const handleNewRequest = async (e: any) => {
      const req = e?.detail as Appointment;
      if (req) {
        setAppointments((prev) => [req, ...prev.filter(a => a.id !== req.id)]);
        try {
          const { saveAppointmentToFirestore } = await import('./services/firestoreService');
          await saveAppointmentToFirestore(req);
        } catch (err) {
          console.error('[App] Error persisting appointment to Firestore in handleNewRequest:', err);
        }
      }
    };
    const handleNotifsUpdate = (e: any) => {
      if (Array.isArray(e?.detail)) {
        const next = e.detail;
        setNotifications((prev) => {
          if (prev.length === next.length && prev.every((n, i) => n.id === next[i].id)) return prev;
          return next;
        });
      }
    };

    window.addEventListener(DISPATCH_REQUEST_EVENT, handleNewRequest);
    window.addEventListener('raba_notifications_updated', handleNotifsUpdate);

    const handleSpecialistsUpdate = (e: any) => {
      if (Array.isArray(e?.detail)) {
        const next = e.detail;
        setSpecialists((prev) => {
          if (prev.length === next.length && prev.every((s, i) => s.id === next[i].id && s.avatar === next[i].avatar)) {
            return prev;
          }
          return next;
        });
      } else {
        try {
          const saved = localStorage.getItem('raba_specialists');
          if (saved) {
            const parsed = JSON.parse(saved);
            if (Array.isArray(parsed) && parsed.length > 0) {
              setSpecialists((prev) => {
                if (prev.length === parsed.length && prev.every((s, i) => s.id === parsed[i].id && s.avatar === parsed[i].avatar)) {
                  return prev;
                }
                return parsed;
              });
            }
          }
        } catch { /* ignore */ }
      }
    };

    const handleAppointmentsUpdate = (e: any) => {
      if (Array.isArray(e?.detail)) {
        const next = e.detail;
        setAppointments((prev) => {
          if (prev.length === next.length && prev.every((a, i) => a.id === next[i].id)) return prev;
          return next;
        });
      }
    };

    const handleSyncReady = () => {
      // Re-read theme and modules
      applyGlobalTheme(getStoredThemeSettings());
      const nextMods = getStoredModulesVisibility();
      setModules((prev) => {
        if (JSON.stringify(prev) === JSON.stringify(nextMods)) return prev;
        return nextMods;
      });

      // Re-read specialists gracefully without loop
      try {
        const savedSpec = localStorage.getItem('raba_specialists');
        if (savedSpec) {
          const parsed = JSON.parse(savedSpec);
          if (Array.isArray(parsed) && parsed.length > 0) {
            const hasStaleMocks = parsed.length !== SPECIALISTS.length ||
              parsed.some((s: any) => 
                s.id === 'spec-rawan-tablett' || 
                s.id === 'spec-hossam-malki' ||
                (s.id === 'spec-hanaa-basheer' && (!s.education || s.education.length < 5 || s.category !== 'psychology' || s.experienceYears !== 15)) ||
                (s.id === 'spec-sara-abdelhamid' && s.name && s.name.includes('يارا')) ||
                (s.id === 'spec-sadeem-mshari' && s.experienceYears !== 2)
              );
            const fullList = hasStaleMocks
              ? SPECIALISTS
              : parsed;
            setSpecialists((prev) => {
              if (prev.length === fullList.length && prev.every((s, i) => s.id === fullList[i].id && s.avatar === fullList[i].avatar)) {
                return prev;
              }
              return fullList;
            });
          }
        }
      } catch { /* ignore */ }

      // Re-read appointments gracefully
      try {
        const savedAppt = localStorage.getItem('raba_appointments');
        if (savedAppt) {
          const parsed = JSON.parse(savedAppt);
          if (Array.isArray(parsed) && parsed.length > 0) {
            setAppointments((prev) => {
              if (prev.length === parsed.length && prev.every((a, i) => a.id === parsed[i].id)) return prev;
              return parsed;
            });
          }
        }
      } catch { /* ignore */ }
    };

    window.addEventListener('raba_specialists_updated', handleSpecialistsUpdate);
    window.addEventListener('raba_appointments_updated', handleAppointmentsUpdate);
    window.addEventListener('raba_persistent_sync_ready', handleSyncReady);

    return () => {
      window.removeEventListener('raba_theme_updated', handleThemeUpdate);
      window.removeEventListener('raba_modules_updated', handleModulesUpdate);
      window.removeEventListener(DISPATCH_REQUEST_EVENT, handleNewRequest);
      window.removeEventListener('raba_notifications_updated', handleNotifsUpdate);
      window.removeEventListener('raba_specialists_updated', handleSpecialistsUpdate);
      window.removeEventListener('raba_appointments_updated', handleAppointmentsUpdate);
      window.removeEventListener('raba_persistent_sync_ready', handleSyncReady);
      cleanupPixels();
      cleanupBelowFold();
    };
  }, []);

  // Persistence state
  const [appointments, setAppointments] = useState<Appointment[]>(() => {
    try {
      const saved = localStorage.getItem('raba_appointments') || localStorage.getItem('khotwa_appointments');
      const list: Appointment[] = saved ? JSON.parse(saved) : INITIAL_APPOINTMENTS;
      // Deduplicate by ID to prevent duplicate key warning
      const seen = new Set<string>();
      return list.filter((item) => {
        if (!item || !item.id) return false;
        if (seen.has(item.id)) return false;
        seen.add(item.id);
        return true;
      });
    } catch {
      return INITIAL_APPOINTMENTS;
    }
  });

  const [notifications, setNotifications] = useState<NotificationItem[]>(() => {
    try {
      const saved = localStorage.getItem('raba_notifications') || localStorage.getItem('khotwa_notifications');
      return saved ? JSON.parse(saved) : INITIAL_NOTIFICATIONS;
    } catch {
      return INITIAL_NOTIFICATIONS;
    }
  });

  const [testimonials, setTestimonials] = useState<ParentReview[]>(() => {
    try {
      const saved = localStorage.getItem('raba_testimonials_v7');
      return saved ? JSON.parse(saved) : PARENT_REVIEWS;
    } catch {
      return PARENT_REVIEWS;
    }
  });

  const [specialists, setSpecialists] = useState<Specialist[]>(() => {
    try {
      const saved = localStorage.getItem('raba_specialists');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          const hasStaleMocks = parsed.length !== SPECIALISTS.length ||
            parsed.some((s: any) => 
              s.id === 'spec-rawan-tablett' || 
              s.id === 'spec-hossam-malki' ||
              (s.id === 'spec-hanaa-basheer' && (!s.education || s.education.length < 5 || s.category !== 'psychology' || s.experienceYears !== 15)) ||
              (s.id === 'spec-sara-abdelhamid' && s.name && s.name.includes('يارا')) ||
              (s.id === 'spec-sadeem-mshari' && s.experienceYears !== 2)
            );
          if (hasStaleMocks) {
            return deduplicateSpecialists(SPECIALISTS);
          }
          return deduplicateSpecialists(parsed);
        }
      }
      return deduplicateSpecialists(SPECIALISTS);
    } catch {
      return deduplicateSpecialists(SPECIALISTS);
    }
  });

  // Save to localStorage (debounced + idle, never on the critical rendering path)
  usePersistIdle('raba_specialists', specialists);
  usePersistIdle('raba_appointments', appointments);
  usePersistIdle('raba_notifications', notifications);
  usePersistIdle('raba_testimonials_v7', testimonials);

  // Modal states
  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isStoreOpen, setIsStoreOpen] = useState(false);
  const [isVideoOpen, setIsVideoOpen] = useState(false);
  const [isQuickConsultOpen, setIsQuickConsultOpen] = useState(false);
  // Page states - Home page is always the default view on startup/load
  const [isAdminOpen, setIsAdminOpen] = useState(() => {
    return window.location.hash === '#admin';
  });
  const [isSpecialistsPageOpen, setIsSpecialistsPageOpen] = useState(false);
  const [isServicesPageOpen, setIsServicesPageOpen] = useState(false);
  const [isBranchesPageOpen, setIsBranchesPageOpen] = useState(false);
  const [isOffersPageOpen, setIsOffersPageOpen] = useState(false);
  const [isBlogPageOpen, setIsBlogPageOpen] = useState(false);
  const [activeBlogSlug, setActiveBlogSlug] = useState<string | null>(null);
  const [adminSession, setAdminSession] = useState<AdminUser | null>(() => getStoredAdminSession());
  const [cartCount, setCartCount] = useState(0);
  const [selectedCourseForRegistration, setSelectedCourseForRegistration] = useState<CourseItem | null>(null);
  const [isCourseRegistrationOpen, setIsCourseRegistrationOpen] = useState(false);

  // Check initial route / hash
  useEffect(() => {
    const initialHash = window.location.hash.toLowerCase();
    const initialPath = window.location.pathname.toLowerCase();
    
    // Dedicated Blog Route Check
    if (
      initialHash === '#blog-directory' ||
      initialHash === '#blog-page' ||
      initialHash === '#articles' ||
      initialHash.startsWith('#blog/') ||
      initialPath === '/blog' ||
      initialPath === '/articles'
    ) {
      setIsReadyToHydrate(true);
      setIsBlogPageOpen(true);
      if (initialHash.startsWith('#blog/')) {
        setActiveBlogSlug(window.location.hash.replace('#blog/', ''));
      }
      return;
    }

    if (
      initialHash === '#specialists-directory' || 
      initialHash === '#specialists-page' ||
      initialHash === '#services-directory' || 
      initialHash === '#services-page' ||
      initialHash === '#branches-directory' || 
      initialHash === '#branches-page' ||
      initialHash === '#offers-directory' ||
      initialHash === '#offers-page' ||
      initialHash === '#offers' ||
      initialHash === '#activities'
    ) {
      window.history.replaceState('', document.title, window.location.pathname + window.location.search);
      setIsSpecialistsPageOpen(false);
      setIsServicesPageOpen(false);
      setIsBranchesPageOpen(false);
      setIsOffersPageOpen(false);
      setIsBlogPageOpen(false);
    }
  }, []);

  const handleOpenCourseRegistration = (course: CourseItem) => {
    setSelectedCourseForRegistration(course);
    setIsCourseRegistrationOpen(true);
  };

  const handleOpenSpecialistsPage = () => {
    setIsSpecialistsPageOpen(true);
    setIsServicesPageOpen(false);
    setIsBranchesPageOpen(false);
    setIsOffersPageOpen(false);
    setIsBlogPageOpen(false);
    window.location.hash = '#specialists-directory';
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenServicesPage = () => {
    setIsServicesPageOpen(true);
    setIsSpecialistsPageOpen(false);
    setIsBranchesPageOpen(false);
    setIsOffersPageOpen(false);
    setIsBlogPageOpen(false);
    window.location.hash = '#services-directory';
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenBranchesPage = () => {
    setIsBranchesPageOpen(true);
    setIsSpecialistsPageOpen(false);
    setIsServicesPageOpen(false);
    setIsOffersPageOpen(false);
    setIsBlogPageOpen(false);
    window.location.hash = '#branches-directory';
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenOffersPage = () => {
    setIsOffersPageOpen(true);
    setIsSpecialistsPageOpen(false);
    setIsServicesPageOpen(false);
    setIsBranchesPageOpen(false);
    setIsBlogPageOpen(false);
    window.location.hash = '#offers-directory';
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenBlogPage = (postSlug?: string) => {
    setIsBlogPageOpen(true);
    setIsSpecialistsPageOpen(false);
    setIsServicesPageOpen(false);
    setIsBranchesPageOpen(false);
    setIsOffersPageOpen(false);
    if (postSlug) {
      setActiveBlogSlug(postSlug);
      window.location.hash = `#blog/${postSlug}`;
    } else {
      setActiveBlogSlug(null);
      window.location.hash = '#blog-directory';
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBackToHome = () => {
    setIsSpecialistsPageOpen(false);
    setIsServicesPageOpen(false);
    setIsBranchesPageOpen(false);
    setIsOffersPageOpen(false);
    setIsBlogPageOpen(false);
    setActiveBlogSlug(null);
    if (
      window.location.hash === '#specialists-directory' || 
      window.location.hash === '#specialists-page' ||
      window.location.hash === '#services-directory' ||
      window.location.hash === '#services-page' ||
      window.location.hash === '#branches-directory' ||
      window.location.hash === '#branches-page' ||
      window.location.hash === '#offers-directory' ||
      window.location.hash === '#offers-page' ||
      window.location.hash === '#offers' ||
      window.location.hash === '#activities' ||
      window.location.hash === '#blog-directory' ||
      window.location.hash === '#blog-page' ||
      window.location.hash === '#articles' ||
      window.location.hash.startsWith('#blog/') ||
      (window.location.hash.startsWith('#blog-') && window.location.hash !== '#blog')
    ) {
      window.history.pushState('', document.title, window.location.pathname + window.location.search);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  useEffect(() => {
    const handleHashChange = () => {
      setIsReadyToHydrate(true);
      setIsAdminOpen(window.location.hash.startsWith('#admin'));
      setIsSpecialistsPageOpen(
        window.location.hash === '#specialists-directory' || 
        window.location.hash === '#specialists-page'
      );
      setIsServicesPageOpen(
        window.location.hash === '#services-directory' || 
        window.location.hash === '#services-page'
      );
      setIsBranchesPageOpen(
        window.location.hash === '#branches-directory' || 
        window.location.hash === '#branches-page'
      );
      setIsOffersPageOpen(
        window.location.hash === '#offers-directory' || 
        window.location.hash === '#offers-page' ||
        window.location.hash === '#offers' ||
        window.location.hash === '#activities'
      );
      
      const hash = window.location.hash.toLowerCase();
      const isBlog = 
        hash === '#blog-directory' ||
        hash === '#blog-page' ||
        hash === '#articles' ||
        hash.startsWith('#blog/') ||
        (hash.startsWith('#blog-') && hash !== '#blog');
      setIsBlogPageOpen(isBlog);
      if (window.location.hash.startsWith('#blog/')) {
        setActiveBlogSlug(window.location.hash.replace('#blog/', ''));
      }
    };
    const handleAuthChange = (e: any) => {
      setAdminSession(e?.detail || getStoredAdminSession());
    };
    window.addEventListener('hashchange', handleHashChange);
    window.addEventListener('raba_admin_auth_changed', handleAuthChange);
    return () => {
      window.removeEventListener('hashchange', handleHashChange);
      window.removeEventListener('raba_admin_auth_changed', handleAuthChange);
    };
  }, []);
  const [selectedCvSpecialist, setSelectedCvSpecialist] = useState<Specialist | null>(null);

  // Lazy modals: only mount (and download) after first open
  const quickConsultEver = useEverTrue(isQuickConsultOpen);
  const loginEver = useEverTrue(isLoginOpen);
  const storeEver = useEverTrue(isStoreOpen);
  const courseRegEver = useEverTrue(isCourseRegistrationOpen);
  const videoEver = useEverTrue(isVideoOpen);
  const cvEver = useEverTrue(selectedCvSpecialist !== null);
  const bookingEver = useEverTrue(isBookingOpen);
  const notifEver = useEverTrue(isNotificationsOpen);

  // Warm the two most-used modals during idle time so their first open feels instant
  useEffect(() => {
    if (!isReadyToHydrate) return;
    const warm = () => {
      import('./components/BookingModal').catch(() => {});
      import('./components/QuickConsultationModal').catch(() => {});
    };
    const id = window.setTimeout(() => {
      if ('requestIdleCallback' in window) (window as any).requestIdleCallback(warm, { timeout: 4000 });
      else warm();
    }, 5000);
    return () => window.clearTimeout(id);
  }, [isReadyToHydrate]);

  // In-page anchors (#services, #specialists, ...) must work even if the target section is not mounted yet
  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey) return;
      const a = (e.target as HTMLElement | null)?.closest?.('a[href^="#"]') as HTMLAnchorElement | null;
      if (!a) return;
      const hash = a.getAttribute('href') || '';
      const id = hash.slice(1);
      if (!id || id.includes('/') || /(directory|page|admin|articles)/i.test(id)) return;
      if (document.getElementById(id)) return; // native jump works
      e.preventDefault();
      scrollToSectionId(id);
    };
    document.addEventListener('click', onClick);
    return () => document.removeEventListener('click', onClick);
  }, []);

  // Pre-selected items for booking flow
  const [bookingInitialService, setBookingInitialService] = useState<ServiceItem | null>(null);
  const [bookingInitialPackage, setBookingInitialPackage] = useState<TherapyPackage | null>(null);
  const [bookingInitialSpecialist, setBookingInitialSpecialist] = useState<Specialist | null>(null);
  const [bookingInitialNotes, setBookingInitialNotes] = useState<string>('');
  const [bookingInitialDate, setBookingInitialDate] = useState<string>('');

  // Handlers
  const handleOpenBooking = () => {
    setIsReadyToHydrate(true);
    setBookingInitialService(null);
    setBookingInitialPackage(null);
    setBookingInitialSpecialist(null);
    setBookingInitialNotes('');
    setBookingInitialDate('');
    setIsBookingOpen(true);
  };

  const handleSelectServiceForBooking = (service: ServiceItem) => {
    setBookingInitialService(service);
    setBookingInitialPackage(null);
    setBookingInitialSpecialist(null);
    setBookingInitialNotes('');
    setBookingInitialDate('');
    setIsBookingOpen(true);
  };

  const handleSelectPackageForBooking = (pkg: TherapyPackage) => {
    setBookingInitialPackage(pkg);
    setBookingInitialService(null);
    setBookingInitialSpecialist(null);
    setBookingInitialNotes('');
    setBookingInitialDate('');
    setIsBookingOpen(true);
  };

  const handleSelectSpecialistForBooking = (specialist: Specialist) => {
    setBookingInitialSpecialist(specialist);
    setBookingInitialService(null);
    setBookingInitialPackage(null);
    setBookingInitialNotes('');
    setBookingInitialDate('');
    setIsBookingOpen(true);
  };

  const handleClaimOffer = (offerTitle: string, discountedPrice?: number) => {
    if (offerTitle.includes('مجاني') || offerTitle.includes('Free') || offerTitle.includes('24/9')) {
      // Saudi National Day 96 Free Day (Thursday 24/09/2026)
      setBookingInitialService(null);
      setBookingInitialPackage(null);
      setBookingInitialSpecialist(null);
      setBookingInitialDate('2026-09-24');
      setBookingInitialNotes('عرض اليوم الوطني السعودي 96: حجز يوم مجاني لجميع العملاء (كود: KSA96-FREE) - الخميس 24/09/2026');
      setIsBookingOpen(true);
    } else if (offerTitle.includes('35%') || offerTitle.includes('الجدد') || offerTitle.includes('New Clients')) {
      // Saudi National Day 96 35% New Clients Offer
      setBookingInitialService(null);
      setBookingInitialPackage(null);
      setBookingInitialSpecialist(null);
      setBookingInitialDate('');
      setBookingInitialNotes('عرض اليوم الوطني السعودي 96: خصم 35% للعملاء الجدد (تسجيل صباحي 08:00 ص - 12:00 م) (كود: KSA96-NEW)');
      setIsBookingOpen(true);
    } else {
      setBookingInitialService(null);
      setBookingInitialPackage(null);
      setBookingInitialSpecialist(null);
      setBookingInitialDate('');
      setBookingInitialNotes(`استفادة من عرض: ${offerTitle}${discountedPrice ? ` (خصم ${discountedPrice}%)` : ''}`);
      setIsBookingOpen(true);
    }
  };

  const handleViewCv = (specialist: Specialist) => {
    setSelectedCvSpecialist(specialist);
  };

  const handleConfirmBooking = async (confirmedAppointment: Appointment) => {
    // Add directly to appointments list (appears instantly in Admin Dashboard) with duplicate protection
    const sanitizedApp = {
      ...confirmedAppointment,
      id: confirmedAppointment.id || `apt-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`
    };
    try {
      const { saveAppointmentToFirestore } = await import('./services/firestoreService');
      await saveAppointmentToFirestore(sanitizedApp);
    } catch (err) {
      console.error('[App] Error saving appointment to Firestore in handleConfirmBooking:', err);
    }

    // Create immediate confirmation notification for user
    const newConfirmationNotif: NotificationItem = {
      id: 'notif-' + Date.now(),
      title: `تم استلام طلب حجز: ${confirmedAppointment.serviceTitle}`,
      message: `تم تسجيل طلب حجز جديد للعميل (${confirmedAppointment.guardianName}) - الطفل (${confirmedAppointment.childName}). رقم الحجز: ${confirmedAppointment.referenceNumber}. الموعد: ${confirmedAppointment.date} (${confirmedAppointment.timeSlot}). سيقوم فريق المركز بالتواصل لتأكيد الموعد.`,
      date: 'الآن',
      type: 'confirmation',
      read: false,
      appointmentId: confirmedAppointment.id,
      channel: 'whatsapp'
    };

    setNotifications((prev) => [newConfirmationNotif, ...prev]);
  };

  const handleMarkAllNotificationsAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  const handleAddTestNotification = (msg: string, type: 'reminder' | 'confirmation') => {
    const testNotif: NotificationItem = {
      id: 'notif-' + Date.now(),
      title: 'تنبيه آلي تجريبي فوري 🔔',
      message: msg,
      date: 'الآن',
      type,
      read: false,
      channel: 'whatsapp'
    };
    setNotifications((prev) => [testNotif, ...prev]);
  };

  const unreadCount = notifications.filter((n) => !n.read).length;

  if (isAdminOpen) {
    if (!adminSession) {
      return (
        <Suspense fallback={<div className="min-h-screen bg-[#0D1B2A] flex items-center justify-center text-[#2E86EB] font-bold">جاري تحميل تسجيل الدخول...</div>}>
          <AdminLoginPage
            onLoginSuccess={(user) => {
              setAdminSession(user);
            }}
            onBackToWebsite={() => {
              setIsAdminOpen(false);
              if (window.location.hash.startsWith('#admin')) {
                window.location.hash = '';
              }
            }}
          />
        </Suspense>
      );
    }

    return (
      <Suspense fallback={<div className="min-h-screen bg-[#0D1B2A] flex items-center justify-center text-[#2E86EB] font-bold">جاري تحميل لوحة التحكم...</div>}>
        <AdminDashboard
          appointments={appointments}
          onUpdateAppointments={setAppointments}
          reviews={testimonials}
          onUpdateReviews={setTestimonials}
          specialists={specialists}
          onUpdateSpecialists={setSpecialists}
          onLogout={() => {
            setAdminSession(null);
            clearStoredAdminSession();
          }}
          onClose={() => {
            setIsAdminOpen(false);
            if (window.location.hash.startsWith('#admin')) {
              window.location.hash = '';
            }
          }}
        />
      </Suspense>
    );
  }

  return (
    <div className="min-h-screen relative flex flex-col font-sans text-slate-900 dark:text-white selection:bg-[#00E5BE] selection:text-slate-950 md:transition-colors md:duration-300 overflow-x-clip w-full max-w-[100vw] pb-16 md:pb-0" dir="rtl">
      
      {/* 1. Gentle Animated Background with floating pediatric shapes */}
      <AnimatedBackground />

      {/* 2. Sticky Header */}
      <Navbar
        onOpenBooking={handleOpenBooking}
        onOpenNotifications={() => setIsNotificationsOpen(true)}
        onOpenLogin={() => setIsLoginOpen(true)}
        onOpenAdmin={() => setIsAdminOpen(true)}
        onOpenStore={() => setIsStoreOpen(true)}
        onOpenSpecialistsPage={handleOpenSpecialistsPage}
        onOpenServicesPage={handleOpenServicesPage}
        onOpenBranchesPage={handleOpenBranchesPage}
        onOpenOffersPage={handleOpenOffersPage}
        onOpenBlogPage={handleOpenBlogPage}
        onGoHome={handleBackToHome}
        isSpecialistsPageOpen={isSpecialistsPageOpen}
        isServicesPageOpen={isServicesPageOpen}
        isBranchesPageOpen={isBranchesPageOpen}
        isOffersPageOpen={isOffersPageOpen}
        isBlogPageOpen={isBlogPageOpen}
        unreadCount={unreadCount}
        cartCount={cartCount}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        
        {isSpecialistsPageOpen ? (
          /* Dedicated Specialists Page with Specialty Filter and Grid Format Display */
          <Suspense fallback={<div className="min-h-[60vh] flex items-center justify-center text-teal-500 font-bold">جاري تحميل دليل الأخصائيين...</div>}>
            <SpecialistsDirectoryPage
              specialists={specialists}
              onBackToHome={handleBackToHome}
              onViewCv={handleViewCv}
              onBookSpecialist={handleSelectSpecialistForBooking}
            />
          </Suspense>
        ) : isServicesPageOpen ? (
          /* Dedicated Comprehensive Services Directory Page (Rehab Programs, Courses, Packages & Pricing in Grid) */
          <Suspense fallback={<div className="min-h-[60vh] flex items-center justify-center text-teal-500 font-bold">جاري تحميل دليل الخدمات الشامل...</div>}>
            <ServicesDirectoryPage
              onBackToHome={handleBackToHome}
              onSelectService={handleSelectServiceForBooking}
              onSelectPackage={handleSelectPackageForBooking}
              onRegisterCourse={handleOpenCourseRegistration}
              onOpenSpecialistsPage={handleOpenSpecialistsPage}
            />
          </Suspense>
        ) : isBranchesPageOpen ? (
          /* Dedicated Branches Directory Page with Cities Filter and Slider/Grid Switcher */
          <Suspense fallback={<div className="min-h-[60vh] flex items-center justify-center text-teal-500 font-bold">جاري تحميل دليل فروع مركز رابا...</div>}>
            <BranchesDirectoryPage
              onBackToHome={handleBackToHome}
              onSelectBranch={(branch) => {
                setBookingInitialNotes(`استفسار وحجز في فرع: ${branch.name} (${branch.cityNameAr})`);
                setIsBookingOpen(true);
              }}
              onOpenBooking={(branchNotes) => {
                if (branchNotes) setBookingInitialNotes(branchNotes);
                setIsBookingOpen(true);
              }}
            />
          </Suspense>
        ) : isOffersPageOpen ? (
          /* Dedicated Offers & Activities Page (Moved from Homepage to Separate Page) */
          <Suspense fallback={<div className="min-h-[60vh] flex items-center justify-center text-teal-500 font-bold">جاري تحميل صفحة العروض والأنشطة...</div>}>
            <OffersDirectoryPage
              onBackToHome={handleBackToHome}
              onClaimOffer={handleClaimOffer}
              onOpenBooking={(notes) => {
                if (notes) setBookingInitialNotes(notes);
                setIsBookingOpen(true);
              }}
            />
          </Suspense>
        ) : isBlogPageOpen ? (
          /* Dedicated Articles & Clinical Blog Directory Page */
          <Suspense fallback={<div className="min-h-[60vh] flex items-center justify-center text-teal-500 font-bold">جاري تحميل المدونة الطبية والدليل المعرفي...</div>}>
            <BlogDirectoryPage
              onBackToHome={handleBackToHome}
              onOpenBooking={(notes) => {
                if (notes) setBookingInitialNotes(notes);
                setIsBookingOpen(true);
              }}
              onBookSpecialist={handleSelectSpecialistForBooking}
              initialPostSlug={activeBlogSlug}
            />
          </Suspense>
        ) : (
          <>
            {/* 3. Hero Section */}
            {modules.hero && (
              <Hero
                onOpenBooking={handleOpenBooking}
                onOpenNotifications={() => setIsNotificationsOpen(true)}
                onOpenVideo={() => setIsVideoOpen(true)}
                onBookSpecialist={handleSelectSpecialistForBooking}
                onViewCv={handleViewCv}
              />
            )}

            {/* Safe, Smooth Background Hydration: Instant FCP/LCP for Hero, then quiet idle mounting */}
            {!isReadyToHydrate ? (
              <div className="min-h-[1200px]" style={{ minHeight: '1200px' }} aria-hidden="true" />
            ) : (
              <>
                {/* 5. Center Achievements & Statistics Bar */}
                {modules.stats && <HomeSection order={0} minHeight={160}><StatsBar /></HomeSection>}

                {/* 8. Occupational & ABA Therapy Programs */}
                {modules.services && (
                  <>
                    <HomeSection order={1} minHeight={600}>
                      <ServicesSection onSelectService={handleSelectServiceForBooking} />
                    </HomeSection>
                    {modules.courses && (
                      <HomeSection order={2} minHeight={520}>
                        <CoursesSliderSection onRegisterCourse={handleOpenCourseRegistration} />
                      </HomeSection>
                    )}
                    <HomeSection order={3} minHeight={650}>
                      <ShadowTeacherSection onSubmitRequest={handleConfirmBooking} />
                    </HomeSection>
                    <HomeSection order={4} minHeight={650}>
                      <PackagesSection onSelectPackage={handleSelectPackageForBooking} />
                    </HomeSection>
                  </>
                )}

                {/* 10. Medical Specialists & CV Exploration */}
                {modules.specialists && (
                  <HomeSection order={5} minHeight={700}>
                    <SpecialistsSection
                      specialists={specialists}
                      onViewCv={handleViewCv}
                      onBookSpecialist={handleSelectSpecialistForBooking}
                      onOpenSpecialistsPage={handleOpenSpecialistsPage}
                    />
                  </HomeSection>
                )}

                {/* 11.4. Branches Network Slider */}
                {modules.branches && (
                  <HomeSection order={6} minHeight={600}>
                    <BranchesSection onOpenBranchesPage={handleOpenBranchesPage} />
                  </HomeSection>
                )}

                {/* 11.45. Partners Horizontal Slider */}
                {modules.partners !== false && (
                  <HomeSection order={7} minHeight={300}><PartnersSection /></HomeSection>
                )}

                {/* 11.5. Accreditations & Certifications Section */}
                {modules.accreditations && (
                  <HomeSection order={8} minHeight={300}><AccreditationsSection /></HomeSection>
                )}

                {/* 12. Client Testimonials & Success Stories */}
                {modules.reviews && (
                  <HomeSection order={9} minHeight={650}>
                    <TestimonialsSection
                      testimonials={testimonials}
                      onAddTestimonial={(newReview) => setTestimonials((prev) => [newReview, ...prev])}
                    />
                  </HomeSection>
                )}

                {/* 13. Clinical Blog & Articles Slider */}
                {modules.blog && (
                  <HomeSection order={10} minHeight={600}>
                    <BlogSliderSection
                      onOpenBooking={handleOpenBooking}
                      onBookSpecialist={handleSelectSpecialistForBooking}
                      onOpenBlogPage={handleOpenBlogPage}
                    />
                  </HomeSection>
                )}
              </>
            )}
          </>
        )}

      </main>

      {/* Footer (Safe Background Hydration, single Suspense, never unmounts) */}
      {isReadyToHydrate && modules.footer && (
        <Suspense fallback={null}>
          <Footer 
            onOpenAdmin={() => setIsAdminOpen(true)} 
            onOpenBlogPage={handleOpenBlogPage}
          />
        </Suspense>
      )}

      {/* Multi-Floating Actions & Mobile Bottom Bar wrapped in Suspense for zero main-thread blocking */}
      {isReadyToHydrate && (
        <Suspense fallback={null}>
          <FloatingActions
            onOpenBooking={handleOpenBooking}
            onOpenNotifications={() => setIsNotificationsOpen(true)}
            onOpenQuickConsult={() => setIsQuickConsultOpen(true)}
          />

          <MobileBottomBar
            onOpenBooking={handleOpenBooking}
            onOpenSpecialistsPage={handleOpenSpecialistsPage}
            onOpenServicesPage={handleOpenServicesPage}
            onOpenBranchesPage={handleOpenBranchesPage}
            onOpenOffersPage={handleOpenOffersPage}
            onGoHome={handleBackToHome}
            isSpecialistsPageOpen={isSpecialistsPageOpen}
            isServicesPageOpen={isServicesPageOpen}
            isBranchesPageOpen={isBranchesPageOpen}
            isOffersPageOpen={isOffersPageOpen}
          />
        </Suspense>
      )}

      {/* Modals wrapped in Suspense for zero initial blocking time */}
      <Suspense fallback={null}>
        {/* Quick Consultation Request Modal */}
        {quickConsultEver && <QuickConsultationModal
          isOpen={isQuickConsultOpen}
          onClose={() => setIsQuickConsultOpen(false)}
          onSuccessSubmit={handleConfirmBooking}
        />}
        {/* Login Modal */}
        {loginEver && <LoginModal
          isOpen={isLoginOpen}
          onClose={() => setIsLoginOpen(false)}
          onOpenAdmin={() => setIsAdminOpen(true)}
        />}

        {/* Store Modal */}
        {storeEver && <StoreModal
          isOpen={isStoreOpen}
          onClose={() => setIsStoreOpen(false)}
          onAddToCart={() => setCartCount((prev) => prev + 1)}
        />}

        {/* Course Registration Modal */}
        {courseRegEver && <CourseRegistrationModal
          course={selectedCourseForRegistration}
          isOpen={isCourseRegistrationOpen}
          onClose={() => {
            setIsCourseRegistrationOpen(false);
            setSelectedCourseForRegistration(null);
          }}
        />}

        {/* Video Presentation Modal */}
        {videoEver && <VideoModal
          isOpen={isVideoOpen}
          onClose={() => setIsVideoOpen(false)}
          onBookNow={handleOpenBooking}
        />}

        {/* Specialist CV Modal */}
        {cvEver && <SpecialistCvModal
          specialist={selectedCvSpecialist}
          onClose={() => setSelectedCvSpecialist(null)}
          onBookSpecialist={handleSelectSpecialistForBooking}
        />}

        {/* Booking Appointment Modal (Direct Booking - No Payment) */}
        {bookingEver && <BookingModal
          isOpen={isBookingOpen}
          onClose={() => setIsBookingOpen(false)}
          initialService={bookingInitialService}
          initialPackage={bookingInitialPackage}
          initialSpecialist={bookingInitialSpecialist}
          initialNotes={bookingInitialNotes}
          initialDate={bookingInitialDate}
          onConfirmBooking={handleConfirmBooking}
        />}

        {/* Client Automated Session Notifications Center */}
        {notifEver && <NotificationCenterModal
          isOpen={isNotificationsOpen}
          onClose={() => setIsNotificationsOpen(false)}
          notifications={notifications}
          appointments={appointments}
          onMarkAllAsRead={handleMarkAllNotificationsAsRead}
          onAddTestNotification={handleAddTestNotification}
        />}
      </Suspense>

    </div>
  );
}
